Code attachment for causal scale attention.

The Python experiment is a CPU reference or synthetic simulation as described in the paper; it does not substantiate unmeasured GPU behavior. The results JSON is the output distributed with the paper. The formal/ directory contains shared Lean 4.35.0 proof sources for narrowly stated algebraic claims; see formal/FORMAL_VERIFICATION.md for assumptions and limits.

Run the experiment with Python 3 from this directory. For Ada-CISA, run `python benchmark/run_benchmark.py`; unit checks are available with `python -m unittest benchmark/test_kernel_simulation.py`.
